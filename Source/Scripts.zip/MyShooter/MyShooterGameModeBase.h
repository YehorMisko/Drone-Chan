// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MyShooterGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class MYSHOOTER_API AMyShooterGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
