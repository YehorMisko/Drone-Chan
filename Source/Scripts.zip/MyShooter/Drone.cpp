// Fill out your copyright notice in the Description page of Project Settings.


#include "Drone.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/BoxComponent.h"
#include "GameFramework/FloatingPawnMovement.h"
#include <GameFramework/DefaultPawn.h>
#include "GameFramework/Character.h"
#include "MyShooterCharacter.h"
#include "Camera/CameraComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Components/SpotLightComponent.h"
#include "Components/WidgetComponent.h"

// Sets default values
ADrone::ADrone()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	SkeletalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Skeletala Mesh"));
	
	CollisionBox = CreateDefaultSubobject<UBoxComponent>(TEXT("Boxa Collision"));
	SetRootComponent(SkeletalMesh);

	PawnMovement = CreateDefaultSubobject<UFloatingPawnMovement>(TEXT("My Name is Skyler White yo"));
	PawnMovement->Acceleration = 2000.0f;
	PawnMovement->Deceleration = 500.0f;
	PawnMovement->TurningBoost = 1.0f;
	PawnMovement->MaxSpeed = 300.0f;
	droneActivated = false;
	//Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	this->bUseControllerRotationYaw = true;
	SceneCaptureCam = CreateDefaultSubobject<USceneCaptureComponent2D>(TEXT("ScenaComponenta"));
	
	CamSpotLight = CreateDefaultSubobject<USpotLightComponent>(TEXT("SpotaLighta"));
	CamSpotLight->SetupAttachment(SceneCaptureCam);
	DroneScreenWidget = CreateDefaultSubobject<UWidgetComponent>(TEXT("Drone Screen Widget"));
	//MovementComponent =
	//class UFloatingPawnMovement MovementComponent = CreateDefaultSubobject<UFloatingPawnMovement>(TEXT("Flota Movementa"));
}

// Called when the game starts or when spawned
void ADrone::BeginPlay()
{
	Super::BeginPlay();
	
}

void ADrone::Activate(ACharacter* Interactor)
{
	
	droneActivated = !droneActivated;
	AController* playerController = Interactor->GetController();
	if (droneActivated == true) {
		playerController->Possess(this);
		UE_LOG(LogTemp, Warning, TEXT("Drone has been possesed"));
		//DroneScreenWidget->ViewPort
	}
	else {
		playerController->UnPossess();
	}
	

	
}

void ADrone::MoveUp(float Value)
{
	if ((Controller != nullptr) && (Value != 0.0f)) {
		//find out which way is forward
		const FRotator Rotation{ Controller->GetControlRotation() };
		const FRotator YawRotation{ 0,Rotation.Yaw ,0 };

		const FVector Direction{ FRotationMatrix{YawRotation}.GetUnitAxis(EAxis::Z) };
		PawnMovement->AddInputVector(Direction * Value);
	}
	//AddMovementInput(Direction, Value);
	//UE_LOG(LogTemp, Warning, TEXT("FlyUp value is : %s"), *Direction.ToString());
	
}

void ADrone::MoveRight(float Value)
{
	if ((Controller != nullptr) && (Value != 0.0f)) {
		//find out which way is forward
		const FRotator Rotation{ Controller->GetControlRotation() };
		const FRotator YawRotation{ 0,Rotation.Yaw ,0 };

		const FVector Direction{ FRotationMatrix{YawRotation}.GetUnitAxis(EAxis::Y) };
		PawnMovement->AddInputVector(Direction * Value);
	}
}

void ADrone::MoveForward(float Value)
{
	if ((Controller != nullptr) && (Value != 0.0f)) {
		//find out which way is forward
		const FRotator Rotation{ Controller->GetControlRotation() };
		const FRotator YawRotation{ 0,Rotation.Yaw ,0 };

		const FVector Direction{ FRotationMatrix{YawRotation}.GetUnitAxis(EAxis::X) };
		PawnMovement->AddInputVector(Direction * Value);
	}
}

void ADrone::TurnRight(float Value)
{
	AddControllerYawInput(Value * 45.0f * GetWorld()->GetDeltaSeconds());
}

// Called every frame
void ADrone::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


// Called to bind functionality to input
void ADrone::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	check(PlayerInputComponent);
	PlayerInputComponent->BindAxis("FlyUp", this, &ADrone::MoveUp);
	PlayerInputComponent->BindAxis("MoveForward", this, &ADrone::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &ADrone::MoveRight);
	PlayerInputComponent->BindAxis("TurnRight", this, &ADrone::TurnRight);
	PlayerInputComponent->BindAxis("Turn", this, &ADrone::AddControllerYawInput);
	//PlayerInputComponent->BindAction("Activate", IE_Pressed, this, &ADrone::Activate);
}

