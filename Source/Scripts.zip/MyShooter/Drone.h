// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "Drone.generated.h"


UCLASS()
class MYSHOOTER_API ADrone : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	ADrone();
	void Activate(ACharacter* Interactor);
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Collision)
		class UBoxComponent* CollisionBox;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = SkeletalMesh)
		class USkeletalMeshComponent* SkeletalMesh;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Movement)
		class UFloatingPawnMovement* PawnMovement;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
		class USceneCaptureComponent2D* SceneCaptureCam;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
		class USpotLightComponent* CamSpotLight;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Camera)
		class UWidgetComponent* DroneScreenWidget;
		//class UCameraComponent* Camera;
	
	//Activates the drone
private:
	UPROPERTY()
		bool droneActivated;
	void MoveUp(float Value);
	void MoveRight(float Value);
	void MoveForward(float Value);
	void TurnRight(float Value);
	
public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	
};
